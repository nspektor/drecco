# Sudokill
### Implementation by Team Marshmallow: Nellie Spektor and Nehemiah Dureus
### Game Created by Dennis Shasha: [description](https://cs.nyu.edu/courses/fall20/CSCI-GA.2965-001/sudokill)

