# Sudokill
### Implementation by Team Marshmallow: Nellie Spektor and Nehemiah Dureus
### Game Created by Dennis Shasha: [description](https://cs.nyu.edu/courses/fall20/CSCI-GA.2965-001/sudokill)

To Do
- Make it so the game checks logic against the whole board (not just the original board) - nellie
- prettify/clarify the UI in the popup and page - nellie
- Board Size Variable - optional
- Color logic for different players' moves - nehemiah
- Highlight most recent move - nehemiah
- Disallow editing already placed numbers - nehemiah
- stop allowing edits after a player loses - nehemiah
- grey out and disable the parts of the board that aren't allowed by the row/col rule. - nehemiah
- Play the game a bunch!!

